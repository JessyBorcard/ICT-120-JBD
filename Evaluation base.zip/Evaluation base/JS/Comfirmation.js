//jessy borcard
//exam project, inscription
//v1.0




function displayName() {
    document.getElementById("name").innerText = localStorage.name;//get the local storage value
    document.getElementById("lastname").innerText = localStorage.lastname;//get the local storage value
}