//jessy borcard
//exam project, inscription
//v1.0






//---------------Global init Var------------
var check_errors = [1,1,1];
var final_check = 1;
//---------------Global init Var------------

function errorMsgsDisplay() {

    //---------------Init Var------------
    var trigger_event = event.target.id;//get the trigger event's id
    var dom_trigger_event = document.getElementById(trigger_event);
    var verif_same_password = document.getElementById("passwordtxt").value;
    var verif_same_password_2 = document.getElementById("password2txt").value;
   var trimmed_trigger_event = trigger_event.replace('txt' ,'error');
   //---------------Init Var------------
    if(trigger_event === "firstnametxt" || trigger_event === "lastnametxt"){

        if(dom_trigger_event.value.length <= 3) {
            document.getElementById(trimmed_trigger_event).style.display = "inline";//show the element
            check_errors[0] = 1;//there is an error so, i save it in a array as a one
        }else{
            document.getElementById(trimmed_trigger_event).style.display = "none";//hide the element
            check_errors[0] = 0;//there is no error so, i save it in a array as a zero
        }
    }
    if(trigger_event === "passwordtxt"){
        if(dom_trigger_event.value.length <= 6) {
            document.getElementById(trimmed_trigger_event).style.display = "inline";
            check_errors[1] = 1;//there is an error so, i save it in a array as a one
        }else{
            document.getElementById(trimmed_trigger_event).style.display = "none";
            check_errors[1] = 0;//there is no error so, i save it in a array as a zero
        }
    }
    if(trigger_event === "password2txt")
    {
        if (verif_same_password_2 !== verif_same_password) {//password verification, only work if the two passwords are similars

            document.getElementById(trimmed_trigger_event).style.display = "inline";
            check_errors[2] = 1;//there is an error so, i save it in a array as a one


        } else {
            document.getElementById(trimmed_trigger_event).style.display = "none";
            check_errors[2] = 0;//there is no error so, i save it in a array as a zero
        }
    }

    for(var i = 0; i < 3; i++) {
        if (check_errors[i] === 0){//check if there is an "one"(error) in the array
            final_check = 0;//if not the final check is zero
        }else{
            final_check = 1;//if there is an error, final check is one
        }

    }
    if(final_check === 0){
        document.getElementById("submitbutton").disabled = false;//if there is no errors at all(final check = 0) then i enable the button
    }else{
        document.getElementById("comfirmbutton").disabled = true;
    }


    localStorage.name  = document.getElementById("firstnametxt").value;//save in a local storage
    localStorage.lastname = document.getElementById("lastnametxt").value;//save in a local storage
            }




            function txtAreaVer() {

                //---------------Init Var------------
            var dom_element = document.getElementById("txtarea");
                var errormsg1 = document.getElementById("error1");
                var errormsg2 = document.getElementById("error2");
var buffer;
                var char_buffer;
                var newchar_buffer;
                var charleft = document.getElementById("charleft");
                //---------------Init Var------------
                if (dom_element.value.length <= 30){//if the text area is smaller than 30 characters, shows the error
                errormsg1.style.display = "block";

            }else{
                errormsg1.style.display = "none";//if not, only show the remaining chars
                errormsg2.style.display = "block";


                buffer = 144-dom_element.value.length;//substract 144(max chars allowed) to the length of the text area and save it
                charleft.innerText = buffer;//save the buffer in charleft, shows the remaining characters
                if(buffer <= 0){//if the limit is overcome
                    char_buffer = dom_element.value;//save the value of the text area in a buffer
                    newchar_buffer = char_buffer.slice(0, - 1);//slice the last value if the max value is greater than 0
                    dom_element.value = newchar_buffer;//save the sliced value in the text area
                    document.getElementById("comfirmbutton").disabled = false;//enable the button
                }else{
                    document.getElementById("comfirmbutton").disabled = true;
                }
            }

            }